<?php

namespace App\Filament\Resources;

use App\Filament\Resources\UserResource\Pages;
use App\Filament\Resources\UserResource\RelationManagers;
use App\Models\User;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;

use Illuminate\Support\Facades\Hash;
use App\Helpers\FilamentAccess;


class UserResource extends Resource
{
    protected static ?string $model = User::class;

    protected static ?string $navigationIcon = 'heroicon-o-rectangle-stack';


    public static function canAccess(): bool
    {
        return FilamentAccess::isAdmin();
    }


    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\TextInput::make('name')->required(),
                Forms\Components\TextInput::make('phone')->required(),
                Forms\Components\TextInput::make('email')->nullable(),
                Forms\Components\Select::make('role')
                    ->options([
                        'user' => 'User',
                        'secretary' => 'Secretary',
                        'admin' => 'Admin',
                    ])->reactive()
                    ->required(),
                Forms\Components\TextInput::make('specialty')->nullable()
                    ->visible(fn($livewire) => ($livewire->data['role'] ?? '') === 'user' || request()->input('role') === 'user'),

                Forms\Components\Select::make('workspace_id')
                    ->relationship('workspace', 'name')
                    ->required(fn($livewire) => $livewire->data['role'] ?? '' === 'secretary' || request()->input('role') === 'secretary')
                    ->visible(fn($livewire) => ($livewire->data['role'] ?? '') === 'secretary' || request()->input('role') === 'secretary')
                    ->label('مساحة العمل المرتبطة')
                    ->searchable(),

                Forms\Components\TextInput::make('password')
                    ->password()
                    ->dehydrateStateUsing(fn($state) => Hash::make($state))
                    ->dehydrated(fn($state) => filled($state))
                    ->label('Password'),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('name'),
                Tables\Columns\TextColumn::make('phone'),
                Tables\Columns\TextColumn::make('email'),
                Tables\Columns\TextColumn::make('role'),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListUsers::route('/'),
            'create' => Pages\CreateUser::route('/create'),
            'edit' => Pages\EditUser::route('/{record}/edit'),
        ];
    }
}
